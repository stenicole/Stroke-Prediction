from fastapi import Depends, FastAPI, HTTPException, status
from fastapi.security import HTTPBasic, HTTPBasicCredentials


import json
import secrets



api = FastAPI(
    title='My exam_API'
)

security = HTTPBasic()

users_db = [
    {
       
        'username': 'Alice',
        'password' : 'wonderland',
        'v1'       : 1,
        'v2'       : 1
        
    },
    {
        
        'username': 'Bob',
        'password' : 'builder',
        'v1'       :  1,
        'v2'       :  0
    },
    {
        
        'username': 'Clementine',
        'password' : 'machine',
        'v1'       :  0,
        'v2'       :  1
    }
]


@api.get("/status")        
async def test():
    return 1


@api.get('/permissions')
async def permissions(credentials: HTTPBasicCredentials = Depends(security)):
   # parcours du fichier data.json
    for user in users_db:
       # vérification de l'username et du password
       if secrets.compare_digest(credentials.username, user['username']) == True and secrets.compare_digest(credentials.password, user['password']) == True:
            # si l'username et le mot de passe sont corrects la liste des
            # permissions est renvoyée
            return {'username': user['username'],
                          'v1': user['v1'], 
                          'v2': user['v2']}
                
   # dans le cas où le user n'est pas trouvé
    raise HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Incorrect email or password",
        headers={"WWW-Authenticate": "Basic"},
    )  


#création du dictionnaire des scores des modeles entraînés et testés
tf = open("app/Modele/Perf/score_ML.json", "r")
score_dic = json.load(tf)

# création de vue des clés du dictionnaire des scores
list_model=score_dic.keys() 

# création d'une route pour obtenir la liste des modeles
@api.get('/modele')
async def get_modele_list():
    """Return list of models
    """
    return list(list_model)

# création d'une route pour obtenir le score d'un modele
@api.get('/score/{modele:str}')
async def get_score_ML(modele):
    """Return score of the selected model
    """
    try:
        return {modele : score_dic[modele]}
    except  KeyError:
        return {}


from typing import Optional
from pydantic import BaseModel
import pandas as pd
from joblib import load

class predict(BaseModel):
     """A predict has to respect this pattern.
       The champs hypertension, heart_disease, ever_married
       Residence_type, work_type_Govt_job, work_type_Never_worked,
       work_type_Private, work_type_Self_employed,
       work_type_children, smoking_status_Unknown,
       smoking_status_formerly_smoked, smoking_status_smokes,
       gender_Female, gender_Male, gender_Other have be equal to 0 or 1.
       0 = no , 1 = yes
       Residence_type : 0 = Rural, 1 = Urban
     """
     age                            : int
     hypertension                   : int
     heart_disease                  : int
     ever_married                   : int
     Residence_type                 : int
     avg_glucose_level              : float
     bmi                            : float
     work_type_Govt_job             : int
     work_type_Never_worked         : int
     work_type_Private              : int
     work_type_Self_employed        : int
     work_type_children             : int
     smoking_status_Unknown         : int
     smoking_status_formerly_smoked : int
     smoking_status_never_smoked    : int
     smoking_status_smokes          : int
     gender_Female                  : int
     gender_Male                    : int
     gender_Other                   : int

# chargement des modèles entraînés
LogReg = load('app/Modele/LogReg.pckl')
KNN = load('app/Modele/KNN.pckl')
SVC = load('app/Modele/SVC.pckl')
DTC = load('app/Modele/DTC.pckl')
RFC = load('app/Modele/RFC.pckl')
BC = load('app/Modele/BC.pckl')
GBC = load('app/Modele/GBC.pckl')
scaler = load('app/Modele/scaler.pckl')
    


# création d'une route pour prédiction
@api.post('/v1/predict/modele')
async def prediction(test_pred : predict, credentials: HTTPBasicCredentials = Depends(security) ):
# parcours du fichier data.json
    for user in users_db:
       # vérification de l'username et du password
       if secrets.compare_digest(credentials.username, user['username']) == True and secrets.compare_digest(credentials.password, user['password']) == True:
            # si l'username et le mot de passe sont corrects 
            # et si le user a accès au modèle v1  
            if user['v1'] == 1 :
                 
                 try:
                    dic = {"age"                            : [test_pred.age],
                            "hypertension"                   : [test_pred.hypertension],
                            "heart_disease"                  : [test_pred.heart_disease],
                            "ever_married"                   : [test_pred.ever_married],
                            "Residence_type"                 : [test_pred.Residence_type],
                            "avg_glucose_level"              : [test_pred.avg_glucose_level],
                            "bmi"                            : [test_pred.bmi],
                            "work_type_Govt_job"             : [test_pred.work_type_Govt_job],
                            "work_type_Never_worked"         : [test_pred.work_type_Never_worked],
                            "work_type_Private"              : [test_pred.work_type_Private],
                            "work_type_Self_employed"        : [test_pred.work_type_Self_employed],
                            "work_type_children"             : [test_pred.work_type_children],
                            "smoking_status_Unknown"         : [test_pred.smoking_status_Unknown],
                            "smoking_status_formerly_smoked" : [test_pred.smoking_status_formerly_smoked],
                            "smoking_status_never_smoked"    : [test_pred.smoking_status_never_smoked],
                            "smoking_status_smokes"          : [test_pred.smoking_status_smokes],
                            "gender_Female"                  : [test_pred.gender_Female],
                            "gender_Male"                    : [test_pred.gender_Male],
                            "gender_Other"                   : [test_pred.gender_Other]
                        }
                  
                       
                    db = pd.DataFrame([test_pred.dict()])
                    X_norm = scaler.transform(db) 
                    y_res = int(LogReg.predict(X_norm))
                    return y_res
                 except:
                    error = "calcul impossible"
                    return error
                
     # dans le cas où le user n'est pas trouvé
    raise HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Incorrect email or password",
        headers={"WWW-Authenticate": "Basic"},
    )  

# création d'une route pour prédiction modèle v2
@api.post('/v2/predict/modele')
async def prediction(test_pred : predict, credentials: HTTPBasicCredentials = Depends(security) ):
# parcours du fichier data.json
    for user in users_db:
       # vérification de l'username et du password
       if secrets.compare_digest(credentials.username, user['username']) == True and secrets.compare_digest(credentials.password, user['password']) == True:
            # si l'username et le mot de passe sont corrects 
            # et si le user a accès au modèle v2  
            if user['v2'] == 1 :
                 
                 try:
                    dic = {"age"                            : [test_pred.age],
                            "hypertension"                   : [test_pred.hypertension],
                            "heart_disease"                  : [test_pred.heart_disease],
                            "ever_married"                   : [test_pred.ever_married],
                            "Residence_type"                 : [test_pred.Residence_type],
                            "avg_glucose_level"              : [test_pred.avg_glucose_level],
                            "bmi"                            : [test_pred.bmi],
                            "work_type_Govt_job"             : [test_pred.work_type_Govt_job],
                            "work_type_Never_worked"         : [test_pred.work_type_Never_worked],
                            "work_type_Private"              : [test_pred.work_type_Private],
                            "work_type_Self_employed"        : [test_pred.work_type_Self_employed],
                            "work_type_children"             : [test_pred.work_type_children],
                            "smoking_status_Unknown"         : [test_pred.smoking_status_Unknown],
                            "smoking_status_formerly_smoked" : [test_pred.smoking_status_formerly_smoked],
                            "smoking_status_never_smoked"    : [test_pred.smoking_status_never_smoked],
                            "smoking_status_smokes"          : [test_pred.smoking_status_smokes],
                            "gender_Female"                  : [test_pred.gender_Female],
                            "gender_Male"                    : [test_pred.gender_Male],
                            "gender_Other"                   : [test_pred.gender_Other]
                        }
                  
                       
                    db = pd.DataFrame([test_pred.dict()])
                    X_norm = scaler.transform(db) 
                    y_res = int(DTC.predict(X_norm))
                    return y_res
                 except:
                    error = "calcul impossible"
                    return error
                
     # dans le cas où le user n'est pas trouvé
    raise HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Incorrect email or password",
        headers={"WWW-Authenticate": "Basic"},
    )  
